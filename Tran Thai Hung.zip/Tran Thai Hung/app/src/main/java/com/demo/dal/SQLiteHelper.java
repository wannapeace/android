package com.demo.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.demo.adapter.RecycleViewAdapter;
import com.demo.model.item;

import java.util.ArrayList;
import java.util.List;

public class SQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "dbthucpham.db";
    private static int DATABASE_VERSION = 1;

    public SQLiteHelper(@Nullable Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        createTable();
        makedata();
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS items(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT," +
                "vendor TEXT," +
                "image INTEGER," +
                "price TEXT)";
        SQLiteDatabase dt = getWritableDatabase();

        dt.execSQL(sql);
    }

    private void makedata() {
        this.addItem(new item("muop dang", "big c", 2, "19000vnd"));
        this.addItem(new item("dau bap", "big a", 1, "9000vnd"));
        this.addItem(new item("sup lo", "big b", 3, "39000vnd"));
        this.addItem(new item("dau bap", "big d", 1, "1000vnd"));
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    public List<item> getAll() {
        List<item> list = new ArrayList<>();
        SQLiteDatabase st = getReadableDatabase();
        String order = "price DESC";
        Cursor rs = st.query("items", null, null, null, null, null, order);
        while (rs != null && rs.moveToNext()) {
            int id = rs.getInt(0);
            String title = rs.getString(1);
            String vendor = rs.getString(2);
            int image = rs.getInt(3);
            String price = rs.getString(4);
            list.add(new item(title, vendor, image, price));
        }
        return list;
    }

    public long addItem(item i) {
        ContentValues values = new ContentValues();
        values.put("title", i.getTitle());
        values.put("vendor", i.getVendor());
        values.put("image", i.getImage());
        values.put("price", i.getPrice());

        SQLiteDatabase sq = getWritableDatabase();
        return sq.insert("items", null, values);
    }


    public int delete(int id) {
        String whereClause = "id = ?";
        String[] whereArgs = {String.valueOf(id)};
        SQLiteDatabase database = getWritableDatabase();
        return database.delete("items", whereClause, whereArgs);
    }

    public List<item> getByTitle(String key) {
        List<item> list = new ArrayList<>();
        String whereClause = "title like ?";
        String[] whereArgs = {"%" + key + "%"};
        SQLiteDatabase database = getReadableDatabase();
        Cursor rs = database.query("items", null, whereClause, whereArgs,
                null, null, null);
        while (rs != null && rs.moveToNext()) {
            int id = rs.getInt(0);
            String title = rs.getString(1);
            String vendor = rs.getString(2);
            int image = rs.getInt(3);
            String price = rs.getString(4);
            list.add(new item(title, vendor, image, price));
        }
        return list;
    }


}
