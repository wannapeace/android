package com.demo.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.ImageLink;
import com.demo.R;
import com.demo.dal.SQLiteHelper;
import com.demo.model.item;

import java.util.ArrayList;
import java.util.List;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.HomeViewHolder>{
    private List<item> list;
    private SQLiteHelper db;
    private ItemListener itemListener;
    public RecycleViewAdapter (){
        list = new ArrayList<>();
    }

    public void setItemListener(ItemListener itemListener) {
        this.itemListener = itemListener;
    }

    public item getItem(int position){
        return list.get(position);
    }
    public void setList(List<item> list){
        this.list = list;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new HomeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {


        item i = list.get(position);
        holder.title.setText(i.getTitle());
        holder.vendor.setText(i.getVendor());
        holder.image.setImageResource(ImageLink.getImageResource(i.getImage()));
        holder.price.setText(i.getPrice());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class HomeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView title, vendor, price;
        private ImageView image;

        public HomeViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.itemTitle);
            vendor = itemView.findViewById(R.id.itemVendor);
            price = itemView.findViewById(R.id.itemPrice);
            image = itemView.findViewById(R.id.detailImage);
        }

        @Override
        public void onClick(View view) {
            if(itemListener!=null) {
                itemListener.onItemClick(view, getAdapterPosition());
            }
        }
    }

    public interface ItemListener {
        void onItemClick(View view, int position);
    }
}
