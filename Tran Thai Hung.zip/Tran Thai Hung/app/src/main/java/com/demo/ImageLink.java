package com.demo;

import java.util.HashMap;


public class ImageLink {

    public static int getImageResource(int id) {
        HashMap<Integer, Integer> map = new HashMap<>();
        map.put(1, R.drawable.img_daubap);
        map.put(2, R.drawable.img_muopdang);
        map.put(3, R.drawable.img_suplo);


        return map.get(id);
    }
}