package com.demo.fragment;

import android.app.DatePickerDialog;
import android.content.ClipData;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.AddActivity;
import com.demo.R;
import com.demo.adapter.RecycleViewAdapter;
import com.demo.dal.SQLiteHelper;
import com.demo.model.item;

import java.util.Calendar;
import java.util.List;

public class FragmentSearch extends Fragment implements View.OnClickListener{
    private SearchView searchView;
    private Button btnSearch;
    private RecyclerView recyclerView;
    private RecycleViewAdapter adapter;
    private SQLiteHelper db;
    private EditText edDate;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search,container,false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        List<item> list = db.getAll();
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                List<item> list = db.getByTitle(s);
                adapter.setList(list);
                return false;
            }
        });
        btnSearch.setOnClickListener(this);

    }

    private void initView(View view) {
        searchView = view.findViewById(R.id.search);
        btnSearch = view.findViewById(R.id.btnSearch);
        recyclerView = view.findViewById(R.id.recyclerView);
        edDate = view.findViewById(R.id.edDate);
        adapter = new RecycleViewAdapter();
        db = new SQLiteHelper(getContext());

    }

    @Override
    public void onClick(View view) {

        if (view == btnSearch) {
            String title = edDate.getText().toString();
            if (!title.isEmpty() ) {
                List<item> list = db.getByTitle(title);
                adapter.setList(list);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        List<item> list = db.getAll();
        adapter.setList(list);
    }
}
