package com.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import com.demo.dal.SQLiteHelper;
import com.demo.model.item;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {
    private int image;
    private EditText editTitle, editPrice, editVendor, editImage;
    private Button btnAdd, btnCancel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        initView();
        btnAdd.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
    }

    private void initView() {

        editTitle = findViewById(R.id.editTitle);
        editPrice = findViewById(R.id.editPrice);
        editVendor = findViewById(R.id.editVendor);
        editImage = findViewById(R.id.editImage);
        btnCancel = findViewById(R.id.btnCancel);
        btnAdd = findViewById(R.id.btnAdd);
    }

    @Override
    public void onClick(View view) {

        if (view == btnAdd) {
            item item = new item(editTitle.getText().toString(), editVendor.getText().toString(), Integer.parseInt(editImage.getText().toString()), editPrice.getText().toString());
            SQLiteHelper db = new SQLiteHelper(this);
            db.addItem(item);
            finish();

        }

        if (view == btnCancel) {
            finish();
        }
    }
}